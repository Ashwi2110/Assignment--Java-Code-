package com.assignment;

import java.util.Scanner;

public class Ass16_Multiplication_Table {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  int n;
	        Scanner sc=new Scanner(System.in);  
	        System.out.println("Enter number");
	        n=sc.nextInt();  
	        System.out.println("Table of " + n);
	        for(int i=1;i<=10;i++)
	        {
	            System.out.println(n +"x" + i + "=" + n*i );
	        }
	}

}

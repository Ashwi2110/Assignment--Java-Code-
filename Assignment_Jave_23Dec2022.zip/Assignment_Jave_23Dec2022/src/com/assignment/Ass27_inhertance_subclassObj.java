package com.assignment;
class A{
    public void print()
    {
        System.out.println("print from superclass A");
    }
} 
class Ass27_B extends A {

 

    public void show()
    {
        System.out.println("Calling from subclass B ");
    }
    public static void main(String[] args) {
        A obj  = new Ass27_B();        //

        obj.print();
        ((Ass27_B)obj).show();

    }

 

}
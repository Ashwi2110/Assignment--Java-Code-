package com.assignment;

public class Ass18_Characters_from_A_to_Z_using_loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c;

	    for(c = 'A'; c <= 'Z'; ++c)
	      System.out.print(c + " ");
	}

}

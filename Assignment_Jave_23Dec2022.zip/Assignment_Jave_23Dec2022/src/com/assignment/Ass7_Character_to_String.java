package com.assignment;

import java.util.Arrays;
import java.util.Scanner;

public class Ass7_Character_to_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter A Chracter\t");
		char ch = sc.next().charAt(0);
		String st = Character.toString(ch);
		// Alternatively
		// string = String.valueOf(ch);
		System.out.println("Covert Char To String");
		System.out.println("The string is :" + st);


		String st1 = "This is great";
		char[] chars = st1.toCharArray();
		System.out.println("Characters in Strings is :"+Arrays.toString(chars));

	}

}

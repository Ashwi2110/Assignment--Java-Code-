package com.assignment;
interface demo{
    static void show() {
        System.out.println("This is a demo method of interface");
    }
}
public class Ass25_ implements demo{
    public static void m1() {
        System.out.println("Main class method");
    }
    public static void main(String[] args) {
    //Java obj = new Java();
    demo.show();
    Ass25_.m1();

	}

}

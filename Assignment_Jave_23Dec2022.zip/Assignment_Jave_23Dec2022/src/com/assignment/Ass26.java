package com.assignment;

public class Ass26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		child ob = new child(2,4);
        ob.avg();   //calling child class method
        ob.add();   //calling parent class method
    }
}

class parent
{
    int a,b;
    public parent(int a,int b)
    {
        this.a=a;
        this.b=b;
    }
    void add()
    {
        System.out.println("Parent class " + (this.a+this.b));
    }

}
class child extends parent
{
    public child(int a, int b) {
        super(a, b);
    }

    void avg()
    {
        System.out.println("child class" + ((a+b)/2));
    }

}